text2pcap -n -l 248 -D -t "%H:%M:%S." fuzzer.log fuzzer.pcapng
