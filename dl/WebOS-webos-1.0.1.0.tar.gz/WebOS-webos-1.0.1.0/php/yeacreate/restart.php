<?php
	shell_exec("/usr/bin/php /home/php/yeacreate/start.php start -d");
	
	// $txt_file = "/tmp/_home_php_yeacreate_start.txt";
 //    if( !file_exists($txt_file) ){
	// 	// shell_exec("/usr/bin/php /home/php/yeacreate/crontab.php > /dev/null 2>&1 ");
 //    }

