
```txt
	yeacreate 项目目录 => 放到目录 /home/php/ 下
    yeacreate/install/index.php 安装文件 放到目录 /home/php/www/ 下
```