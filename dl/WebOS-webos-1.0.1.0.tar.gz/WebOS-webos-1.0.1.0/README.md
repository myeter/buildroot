WebOS v0101

```txt
This is the WebOS for Ntablet.
It's also a test DEMO for Ntablet.
Depends on Chromium and PHP
It's a Laravel base system, VUE as UI.
clone it , and copy all files into /home directory , and reboot the deivce.
```

